﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows.Input;
using VoorbeeldExamen_bib.Models;
using VoorbeeldExamen_boeken.Models;
using VoorbeeldExamen_boeken.Services;
using VoorbeeldExamen_boeken.Utilities;

namespace VoorbeeldExamen_boeken.ViewModels
{
    public class LedenViewModel : ObservableObject
    {
        private IDataService _dataService;
        private Lid _selectedLid;
        public Lid SelectedLid
        {
            get { return _selectedLid; }
            set { OnPropertyChanged(ref _selectedLid, value); }
        }

        private ObservableCollection<Lid> _leden;
        

        public LedenViewModel(IDataService dataService)
        {
            _dataService = dataService;
           // Leden = new ObservableCollection<Lid>(_dataService.GeefAlleLeden());

            //...

        }



        private void VerwijderLid()
        {
      
        }

        private void WijzigLidGegevens()
        {
            
        }

        private void VoegLidToe()
        {

        }

        public ObservableCollection<Lid> Leden
        {
            get { return _leden; }
            set { OnPropertyChanged(ref _leden, value); }
        }
    }
}
