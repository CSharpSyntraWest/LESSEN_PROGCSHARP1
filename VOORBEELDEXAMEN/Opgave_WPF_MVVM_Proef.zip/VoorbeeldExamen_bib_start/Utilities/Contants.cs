﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoorbeeldExamen_boeken.Utilities
{
    public static class Constants
    {
        public const string IE_path = @"C:\Program Files\Internet Explorer\IExplore.exe";
    }
}
