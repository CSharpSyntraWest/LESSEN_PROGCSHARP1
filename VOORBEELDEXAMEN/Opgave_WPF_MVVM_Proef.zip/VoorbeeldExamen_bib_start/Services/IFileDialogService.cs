﻿namespace VoorbeeldExamen_boeken.Services
{
    public interface IFileDialogService
    {
        string OpenFile(string filter);
    }
}