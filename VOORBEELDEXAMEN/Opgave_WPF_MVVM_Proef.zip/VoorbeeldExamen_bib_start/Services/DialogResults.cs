﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoorbeeldExamen_boeken.Services
{
    public enum DialogResults
    {
        Undefined,
        Yes,
        No,
        Cancel
    }
}
